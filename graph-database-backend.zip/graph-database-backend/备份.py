from flask import Flask, request, jsonify
from nebula3.gclient.net import ConnectionPool
from nebula3.Config import Config
import logging
from flask_cors import CORS
from datetime import datetime

app = Flask(__name__)
CORS(app)  # 允许所有域名跨域访问

# 配置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# NebulaGraph配置
config = Config()
config.max_connection_pool_size = 10
connection_pool = ConnectionPool()

# 初始化连接池
if not connection_pool.init([('172.18.112.199', 9669)], config):
    logger.error('连接NebulaGraph失败')
    exit(1)

# 定义属性到类型的映射
PROPERTY_TYPES = {
    'publishtimestamp': 'timestamp',
    'isrumor': 'bool',
    'title': 'string',
    'content': 'string',
    'event': 'string',
    'uid': 'string',
    'pics_id': 'string',
    'pics_url': 'string',
    'rumor_c': 'string',
    'datasource': 'string',
    'eid': 'string'
}

# 辅助函数：处理NebulaGraph返回的值
def process_value(value, prop_type):
    """根据属性类型处理NebulaGraph返回的值"""
    if value is None:
        return None
    
    # 尝试直接访问值的内容
    processed_value = value
    
    # 检查是否为可直接解码的字节串
    if isinstance(value, bytes):
        try:
            processed_value = value.decode('utf-8')
        except UnicodeDecodeError:
            processed_value = str(value)
    
    # 尝试常见的NebulaGraph值类型访问方式
    try:
        # 检查是否有to_dict方法（某些客户端版本可能提供）
        if hasattr(value, 'to_dict'):
            processed_value = value.to_dict()
        # 检查是否有get_string方法
        elif hasattr(value, 'get_string'):
            processed_value = value.get_string()
        # 检查是否有value属性
        elif hasattr(value, 'value'):
            processed_value = value.value
        # 检查是否有as_string方法
        elif hasattr(value, 'as_string'):
            processed_value = value.as_string()
        # 检查是否有sVal属性
        elif hasattr(value, 'sVal'):
            processed_value = value.sVal
    except Exception:
        pass
    
    # 再次检查处理后的值是否为字节串
    if isinstance(processed_value, bytes):
        try:
            processed_value = processed_value.decode('utf-8')
        except UnicodeDecodeError:
            processed_value = repr(processed_value)
    
    try:
        if prop_type == 'timestamp':
            # 尝试将时间戳转换为可读格式
            if isinstance(processed_value, int):
                # 假设时间戳是毫秒级的
                return datetime.fromtimestamp(processed_value / 1000).strftime('%Y-%m-%d %H:%M:%S')
            return str(processed_value)
        elif prop_type == 'bool':
            return bool(processed_value)
        elif prop_type == 'int':
            return int(processed_value)
        elif prop_type == 'float':
            return float(processed_value)
        else:
            # 默认为字符串类型
            return str(processed_value)
    except Exception:
        return str(processed_value)
# 辅助函数：执行NebulaGraph查询
def execute_query(query, params=None):
    """执行NebulaGraph查询并返回处理后的结果"""
    try:
        with connection_pool.session_context('root', 'p') as session:
            session.execute('USE Social_Network')
            
            # 执行查询 - 兼容旧版本和新版本的NebulaGraph客户端
            if params:
                # 检查是否有execute_parameterized方法
                if hasattr(session, 'execute_parameterized'):
                    result = session.execute_parameterized(query, params)
                else:
                    # 构建带参数的查询字符串
                    formatted_query = query
                    for key, value in params.items():
                        # 简单的参数替换，注意这不是安全的SQL注入防护
                        # 生产环境建议使用官方推荐的参数化方法
                        if isinstance(value, str):
                            formatted_query = formatted_query.replace(f"${key}", f"'{value}'")
                        else:
                            formatted_query = formatted_query.replace(f"${key}", str(value))
                    result = session.execute(formatted_query)
            else:
                result = session.execute(query)
            
            # 检查执行是否成功
            if not result.is_succeeded():
                error_msg = result.error_msg()
                logger.error(f"查询执行失败: {error_msg}, 查询: {query}")
                return {"error": error_msg, "query": query}
            
            # 处理结果集
            rows = []
            if result.is_empty():
                return rows
                
            # 获取列名
            col_names = result.keys()
            
            # 处理每一行数据
            for row in result.rows():
                row_data = {}
                for i, col_name in enumerate(col_names):
                    # 提取tag和property名称
                    parts = col_name.split('.')
                    if len(parts) == 2:
                        _, prop_name = parts
                    else:
                        prop_name = col_name
                    
                    # 获取属性类型，默认为string
                    prop_type = PROPERTY_TYPES.get(prop_name, 'string')
                    
                    # 处理单元格值
                    value = row.values[i]
                    processed_value = process_value(value, prop_type)
                    row_data[prop_name] = processed_value
                
                rows.append(row_data)
            
            return rows
    
    except Exception as e:
        logger.error(f"执行查询时发生异常: {str(e)}, 查询: {query}")
        return {"error": str(e), "query": query}
'''
# 获取所有节点类型的统计信息
@app.route('/api/getNodeStats', methods=['GET'])
def get_node_stats():
    tags_result = execute_query("SHOW TAGS;")
    if "error" in tags_result:
        return jsonify(tags_result), 500

    # 解析标签名称
    tags = [row.get('Name') for row in tags_result]
    logger.info(f"获取到标签: {tags}")

    stats = {}
    for tag in tags:
        count_query = f"MATCH (v:{tag}) RETURN count(v) AS count;"
        count_result = execute_query(count_query)

        if "error" in count_result:
            logger.error(f"统计标签 {tag} 失败: {count_result['error']}")
            continue

        if count_result and len(count_result) > 0:
            stats[tag] = count_result[0]['count']

    return jsonify(stats)

# 获取所有边类型的统计信息
@app.route('/api/getEdgeStats', methods=['GET'])
def get_edge_stats():
    edges_result = execute_query("SHOW EDGES;")
    if "error" in edges_result:
        return jsonify(edges_result), 500

    # 解析标签名称
    edges = [row.get('Name') for row in edges_result]
    logger.info(f"获取到边类型: {edges}")

    stats = {}
    for edge in edges:
        count_query = f"MATCH ()-[e:{edge}]->() RETURN count(e) AS count;"
        count_result = execute_query(count_query)

        if "error" in count_result:
            logger.error(f"统计边 {edge} 失败: {count_result['error']}")
            continue

        if count_result and len(count_result) > 0:
            stats[edge] = count_result[0]['count']

    return jsonify(stats)

@app.route('/api/test', methods=['GET'])
def test():
    return jsonify({"message": "测试成功"})
'''


# 执行自定义CQL查询
@app.route('/api/executeCustomQuery', methods=['POST'])
def execute_custom_query():
    query = request.json.get('query')
    if not query:
        return jsonify({"error": "缺少必要参数: query"}), 400

    result = execute_query(query)
    if "error" in result:
        return jsonify(result), 500

    return jsonify(result)

# 在应用启动时重建索引
with connection_pool.session_context('root', 'p') as session:
    session.execute('USE Social_Network')
    rebuild_index_query = "REBUILD TAG INDEX Article_event"
    rebuild_result = session.execute(rebuild_index_query)
    if not rebuild_result.is_succeeded():
        logger.error(f"重建索引失败: {rebuild_result.error_msg()}")
    else:
        logger.info("索引重建成功")

# 根据事件名称查询文章
@app.route('/api/getArticlesByEvent', methods=['GET'])
def get_articles_by_event():
    event_name = request.args.get('event_name', '')
    event_name ='马斯克宣布向特朗普团队再捐1亿美元'
    logger.info("查询事件名称: %s", event_name)

    if not event_name:
        return jsonify({"error": "请提供事件名称"}), 400

    query = """
    MATCH (a:Article{event: $event_name})
    RETURN 
        a.Article.title AS title,
        a.Article.content AS content,
        a.Article.publishtimestamp AS publishtimestamp,
        a.Article.event AS event,
        a.Article.uid AS uid,
        a.Article.pics_id AS pics_id,
        a.Article.pics_url AS pics_url,
        a.Article.isrumor AS isrumor,
        a.Article.rumor_c AS rumor_c,
        a.Article.datasource AS datasource,
        a.Article.eid AS eid
    """
    params = {"event_name": event_name}
    result = execute_query(query, params)

    return jsonify({
        "event_name": event_name,
        "articles": result,
        "count": len(result)
    })

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)